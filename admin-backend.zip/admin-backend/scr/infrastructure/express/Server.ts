import  express from "express";

const app = express();
const PORT = 3001;

app.listen(PORT, () => {
    console.log(`Server running on http://localhots:${PORT}`);
});

app.get("/", (req, res) => {
    return res.status(200).json({
        statusCode: 200,
        message: "Yago Cavalcante - Site - 2023",
    });
});