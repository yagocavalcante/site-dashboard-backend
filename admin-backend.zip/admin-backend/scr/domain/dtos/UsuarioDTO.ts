export type UsuarioDTO = {
    id: number;
    nome: string;
    email: string;
    senha: string;
    data_cadastro: Date;
    admin: boolean;
};