export default class Usuario{
    id: number;
    nome: string;
    email: string;
    senha: string;
    data_cadastro: Date;
    admin: boolean;

    constructor(
        id: number,
        nome: string,
        email: string,
        senha: string,
        data_cadastro: Date,
        admin: Boolean
     ) {
        this.id;
        this.nome;
        this.email;
        this.senha;
        this.data_cadastro;
        this.admin;
    }
}